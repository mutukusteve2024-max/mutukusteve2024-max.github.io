# Steve's Personal Site (GitHub Pages)

This is a minimal, modern, single‑page site for **Engineer · Project Manager · Author**.

## Quick Deploy (User Site)
1. Create a repo named **`<username>.github.io`** (e.g., `mutukusteve2024-max.github.io`).
2. Upload all files from this folder to the repo root.
3. Commit to the **main** branch.
4. In **Settings → Pages**, choose **Deploy from a branch**, branch **main**, folder **/** (root).
5. Visit `https://<username>.github.io`.

## Custom Domain (Optional)
- Add a file named `CNAME` (no extension) at the repo root with just your domain (e.g., `stevemutuku.com`).
- Set DNS at your domain registrar:
  - A @ → `185.199.108.153`
  - A @ → `185.199.109.153`
  - A @ → `185.199.110.153`
  - A @ → `185.199.111.153`
  - CNAME `www` → `<username>.github.io`
- Back in **Settings → Pages**, enable **Enforce HTTPS** once available.

## Editing Content
Open **index.html** and edit the sections:
- About: 120–150 words bio
- Projects: add cards, links, and assets
- Books: add real Amazon links
- Insights: paste short posts or link out
- Contact: set your real email and social links

## Optional checks (local machine)
You can open `index.html` directly in a browser. No build step needed.
